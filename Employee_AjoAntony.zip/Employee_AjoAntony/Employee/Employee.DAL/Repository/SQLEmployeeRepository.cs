﻿using Employee.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Employee.DAL
{
    public class SQLEmployeeRepository : IEmployeeRepository
    {
        #region Inject Dependencies
        private readonly EmpDbContext _empDbContext;
        public SQLEmployeeRepository(EmpDbContext dbContext)
        {
            _empDbContext = dbContext;
        }
        #endregion

        #region Implementing the Interface -- DB operations for Employee data manipulation
        //Add a new employee
        public Employe Add(Employe emp)
        {
            _empDbContext.Employees.Add(emp);
            _empDbContext.SaveChanges();
            return emp;
        }

        //Delete a particulare employee whose Id is passed
        public Employe Delete(int empId)
        {
            Employe emp = _empDbContext.Employees.Find(empId);
            if (emp != null)
            {
                _empDbContext.Employees.Remove(emp);
                _empDbContext.SaveChanges();
            }
            return emp;
        }

        //Return the details of all employees
        public IEnumerable<Employe> GetAllEmployees()
        {
            return _empDbContext.Employees;
        }

        //Return the details of a prticulare employee based on the Id passed
        public Employe GetEmployee(int Id)
        {
            return _empDbContext.Employees.Find(Id);
        }

        //Update details of a prticulare employee
        public Employe Update(Employe empl)
        {
            //Employe updEmp = _empDbContext.EmployeeT.Find(empl.Id);

            //updEmp.Name = empl.Name;
            //updEmp.Email = empl.Email;
            //updEmp.Department = empl.Department;

            //_empDbContext.EmployeeT.Update(empl);

            var changedEmp = _empDbContext.Employees.Attach(empl);
            changedEmp.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _empDbContext.SaveChanges();
            return empl;
        }
        #endregion
    }
}
