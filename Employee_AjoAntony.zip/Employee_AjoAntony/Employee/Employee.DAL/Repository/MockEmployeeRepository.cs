﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Model;

namespace Employee.DAL
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        private List<Employe> _EmployeeList;

        #region Employee Inmemory Data
        public MockEmployeeRepository()
        {
            _EmployeeList = new List<Employe>()
            {
                new Employe() { Id = 1, Name = "Mary", Email = "mary@yahoo.com", Department = "HR" },
                new Employe() { Id = 2, Name = "John", Email = "john@yahoo.com", Department = "IT" } ,
                new Employe() { Id = 3, Name = "Sam", Email = "sam@yahoo.com", Department = "IT"}
            };
        }
        #endregion

        #region Implementing the Interface for Employee data manipulation
        //Return the details of a prticulare employee based on the Id passed
        public Employe GetEmployee(int Id)
        {
            return _EmployeeList.FirstOrDefault(e => e.Id == Id);
        }

        //Return the details of all employees
        public IEnumerable<Employe> GetAllEmployees()
        {
            return _EmployeeList;
        }

        //Add a new employee
        public Employe Add(Employe emp)
        {
            emp.Id = _EmployeeList.Max(emp => emp.Id) + 1;
            _EmployeeList.Add(emp);
            return emp;
        }

        //Update details of a prticulare employee
        public Employe Update(Employe empl)
        {
            Employe updEmp = _EmployeeList.FirstOrDefault(emp => emp.Id == empl.Id);
            updEmp.Name = empl.Name;
            updEmp.Email = empl.Email;
            updEmp.Department = empl.Department;
            return updEmp;
        }

        //Delete a particulare employee whose Id is passed
        public Employe Delete(int empId)
        {
            Employe delEmp = _EmployeeList.FirstOrDefault(emp => emp.Id == empId);
            _EmployeeList.Remove(delEmp);
            return delEmp;
        }
        #endregion
    }
}
