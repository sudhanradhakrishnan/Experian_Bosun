﻿using Microsoft.EntityFrameworkCore;
using Employee.DAL;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Employee.Model;

namespace Employee.DAL
{
    public class EmpDbContext : DbContext
    {
        public DbSet<Employe> Employees { get; set; }
        public EmpDbContext(DbContextOptions<EmpDbContext> _empDbContext) : base(_empDbContext)
        {
            
        }

        
    }
}
