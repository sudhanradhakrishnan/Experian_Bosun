﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Model;

namespace Employee.DAL
{
    public interface IEmployeeRepository
    {
        Employe GetEmployee(int Id);
        IEnumerable<Employe> GetAllEmployees();
        Employe Add(Employe emp);
        Employe Update(Employe emp);
        Employe Delete(int empId);
    }
}
