﻿using System;
using System.Collections.Generic;
using System.Text;
using Employee.Model;
using Employee.DAL;

namespace Employee.Business.Services
{
    #region Interfaces
    public interface IEmployeeService
    {
        Employe GetEmployee(int Id);
        IEnumerable<Employe> GetAllEmployees();
        Employe Add(Employe emp);
        Employe Update(Employe emp);
        Employe Delete(int empId);
    }
    #endregion

    #region Employee Service class
    public class EmployeeService : IEmployeeService
    {
        #region Inject Dependencies
        private readonly EmpDbContext _empDbContext;
        public EmployeeService(EmpDbContext dbContext)
        {
            _empDbContext = dbContext;
        }
        #endregion

        #region Implementing the Interface -- DB operations for Employee 
        public Employe Add(Employe emp)
        {
            _empDbContext.EmployeeT.Add(emp);
            _empDbContext.SaveChanges();
            return emp;
        }

        public Employe Delete(int empId)
        {
            Employe emp = _empDbContext.EmployeeT.Find(empId);
            if (emp != null)
            {
                _empDbContext.EmployeeT.Remove(emp);
                _empDbContext.SaveChanges();
            }
            return emp;
        }

        public IEnumerable<Employe> GetAllEmployees()
        {
            return _empDbContext.EmployeeT;
        }

        public Employe GetEmployee(int Id)
        {
            return _empDbContext.EmployeeT.Find(Id);
        }

        public Employe Update(Employe empl)
        {

            var changedEmp = _empDbContext.EmployeeT.Attach(empl);
            changedEmp.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _empDbContext.SaveChanges();
            return empl;
        }
        #endregion
    }
    #endregion
}
