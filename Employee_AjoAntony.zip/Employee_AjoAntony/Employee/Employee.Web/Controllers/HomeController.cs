﻿//using Employee.DAL;
using Employee.Model;
using Employee.Business.Services;
using Asp.NetCoreDemo1.ViewModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetCoreDemo1.Controllers
{
    //[Route("Home")]
    public class HomeController :Controller
    {
        //To 
        private readonly IEmployeeService _employeeService;

        //Injecting dependency
        public HomeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        //public JsonResult Index()
        //{
        //    return Json(new { Id = 10, Name = "Peter"});
        //}

        public string Index()
        {
            return _employeeService.GetEmployee(1).Name;
        }

        //public ObjectResult Details()
        //{
        //    Employee emp = new Employee();
        //    emp = _employeeRepository.GetEmployee(1);
        //    return new ObjectResult(emp);
        //}

        //public JsonResult Details()
        //{
        //    Employee emp = new Employee();
        //    emp = _employeeRepository.GetEmployee(1);
        //    return Json(emp);
        //}

        //Usage of ViewData and ViewBag
        public ViewResult Details()
        {
            Employe emp = new Employe();
            emp = _employeeService.GetEmployee(1);

            //How to use ViewData[""]
            ViewData["PageTitle"] = "Employee Details";
            ViewData["Employee"] = emp;

            //How to use ViewBag
            emp = _employeeService.GetEmployee(2);
            ViewBag.Employee = emp;
            ViewBag.PageTitle = "Usage of ViewBag";

            //return View("Test1");

            //Binding Model to View
            emp = _employeeService.GetEmployee(3);
            return View(emp);
        }

        //Usage of Viewmodel return a particular employee
        public ViewResult ViewModelExample()
        {
            Employe emp = new Employe();
            emp = _employeeService.GetEmployee(3);

            EmployeeViewModel EmployeeVM = new EmployeeViewModel()
            { 
                Employee = emp, 
                PageTitle = "ViewModel Example" 
            };
            
            return View("ViewModelTest", EmployeeVM);
        }

        //Return entire set of Employees
        public ViewResult EmployeeList()
        {
            var result = _employeeService.GetAllEmployees();
            return View(result);
        }

        //Testing the Usage of layout page shared among multiple pages
        public ViewResult LayoutTest()
        {
            var result = _employeeService.GetAllEmployees();
            ViewBag.PageTitle = "Usage of common Layout pages";

            return View(result);
        }

        public ViewResult RoutingTestEmployeeDetails(int? Id) //Conventional routing
        {
            Employe emp = new Employe();

            ViewBag.PageTitle = "Conventional Routing Configured";

            //Binding Model to View
            emp = _employeeService.GetEmployee(Id ?? 1);
            return View(emp);
        }

        //Attribute routing by default when the page loads, this action method will be called
        [Route("")]
        [Route("Home")]
        [Route("Home/Index")]
        [Route("Home/AttributeRoutingEmployeeList")]
        public ViewResult AttributeRoutingEmployeeList()
        {
            var result = _employeeService.GetAllEmployees();
            return View("EmployeeList", result);
        }

        //Attribute routing with parameters return the employee based on the EmployeeId passed
        [Route("Home/AttributeRoutingEmployeeListWithParam/{Id?}")]
        public ViewResult AttributeRoutingEmployeeListWithParam(int? Id)
        {
            var result = _employeeService.GetEmployee(Id ?? 1);
            return View("RoutingTestEmployeeDetails", result);
        }
    }
}
