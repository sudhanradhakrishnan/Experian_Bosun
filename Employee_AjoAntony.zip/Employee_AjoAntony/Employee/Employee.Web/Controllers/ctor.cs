﻿namespace Asp.NetCoreDemo1.Controllers
{
    internal class ctor
    {
    }
}