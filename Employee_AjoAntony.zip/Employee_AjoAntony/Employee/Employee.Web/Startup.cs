using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Employee.DAL;
using Employee.Business.Services;
using Microsoft.EntityFrameworkCore;

namespace Asp.NetCoreDemo1
{
    public class Startup
    {
        private IConfiguration _config;

        public Startup(IConfiguration iconfig)
        {
            _config = iconfig;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            //9. To enable MVC services call the services.AddMvc() method, for Raizor Views add AddRazorViewEngine() extension method

            //services.AddMvc(M => M.EnableEndpointRouting = false);
            
            services.AddDbContextPool<EmpDbContext>(db => db.UseSqlServer(_config.GetConnectionString("EmployeeDBConnection")));
            services.AddMvcCore(M => M.EnableEndpointRouting = false).AddRazorViewEngine();


            //10. For Dependency Injection of IEmployeeRepository do one of the followig
            services.AddScoped<IEmployeeRepository, SQLEmployeeRepository>();
            services.AddScoped<IEmployeeService, EmployeeService>();
            //services.AddSingleton<IEmployeeRepository, MockEmployeeRepository>();
            //services.AddScoped<IEmployeeRepository, MockEmployeeRepository>();
            //services.AddTransient<IEmployeeRepository, MockEmployeeRepository>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILogger<Startup> logger)
        {
            
            //7. For Exception handling use UseDeveloperExceptionPage() Middleware as below
            if (env.IsDevelopment())
            {
                //How many lines of Code to be displayed before and after exception Code.
                DeveloperExceptionPageOptions developerExceptionPageOptions = new DeveloperExceptionPageOptions();
                developerExceptionPageOptions.SourceCodeLineCount = 5;
                app.UseDeveloperExceptionPage(developerExceptionPageOptions);

                ///app.UseDeveloperExceptionPage();
            }

            //................................................................................................
            //3. Inorder to use Static files such as .Js file, .css file, image files, should give the below Middleware
            app.UseStaticFiles();

            //app.UseRouting();

            //For default Routing use app.UseMvcWithDefaultRoute();
            //app.UseMvcWithDefaultRoute();

            //For Conventional Routing follow below code pattern. Param 1 is Name of the Route. Param 2 is Controller name Action name and Parameter.
            //If parameter not passed add ? after the parameter to make it optional
            app.UseMvc(route => route.MapRoute("DefaultRoutingName", "{controller=Home}/{action=Details}/{Id?}"));

            //If your application is using only Attribute Routing give the below code instead of above commented code which is for conventional routing and default Routing
            //app.UseMvc();

            //1. The app.Run will be the last middleware method and is the treminal method.
            //Aany Middleware can be added using app.Use() method and has to be added in the order of execution 
            //and the last one will be app.Run
            app.Run(async (context) =>
            {
                //7. For Exception handling, after adding the UseDeveloperExceptionPage Middleware, use the below code to throw exception
                //throw new Exception("Exception message : Some error occurred");

                //await context.Response.WriteAsync("The Hosting environment is : " + env.EnvironmentName);
                //logger.LogInformation("Middleware 3 incoming request.");

                await context.Response.WriteAsync("Hello Ajo ");
            });
        }
    }
}
