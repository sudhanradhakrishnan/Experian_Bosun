CreditCardPreCheckTool

1.CreditCardPreCheckTool project developed using VS 2019, .Net Core 2.1 and MVC.
2.Test Project CreditCardPreQualificationTests created with Test Methods 
3.Database will be created on running the application using MVC Entity Framework Core CodeFirst approach.
4.In appsettings.json file,connectionstring details are specified as below

 "Server=(LocalDb)\\MSSQLLocalDb;Database=CreditCardPreQualification;Trusted_Connection=True;MultipleActiveResultSets=true"
5.Error Logging is implemented to log errormessages to file mentioned in nlog.config file.
  Path given is "c:/Logs/CreditCardPreQualification" log file




