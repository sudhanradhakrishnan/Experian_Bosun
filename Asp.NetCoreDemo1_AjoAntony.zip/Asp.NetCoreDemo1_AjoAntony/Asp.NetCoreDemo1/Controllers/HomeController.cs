﻿using Employee.DAL;
using Employee.Model;
using Asp.NetCoreDemo1.ViewModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetCoreDemo1.Controllers
{
    //[Route("Home")]
    public class HomeController :Controller
    {
        //To 
        private readonly IEmployeeRepository _employeeRepository;

        public HomeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        //public JsonResult Index()
        //{
        //    return Json(new { Id = 10, Name = "Peter"});
        //}

        public string Index()
        {
            return _employeeRepository.GetEmployee(1).Name;
        }

        //public ObjectResult Details()
        //{
        //    Employee emp = new Employee();
        //    emp = _employeeRepository.GetEmployee(1);
        //    return new ObjectResult(emp);
        //}

        //public JsonResult Details()
        //{
        //    Employee emp = new Employee();
        //    emp = _employeeRepository.GetEmployee(1);
        //    return Json(emp);
        //}

        public ViewResult Details()
        {
            Employe emp = new Employe();
            emp = _employeeRepository.GetEmployee(1);

            //How to use ViewData[""]
            ViewData["PageTitle"] = "Employee Details";
            ViewData["Employee"] = emp;

            //How to use ViewBag
            emp = _employeeRepository.GetEmployee(2);
            ViewBag.Employee = emp;
            ViewBag.PageTitle = "Usage of ViewBag";

            //return View("Test1");

            //Binding Model to View
            emp = _employeeRepository.GetEmployee(3);
            return View(emp);
        }

        public ViewResult ViewModelExample()
        {
            Employe emp = new Employe();
            emp = _employeeRepository.GetEmployee(3);

            EmployeeViewModel EmployeeVM = new EmployeeViewModel()
            { 
                Employee = emp, 
                PageTitle = "ViewModel Example" 
            };
            
            return View("ViewModelTest", EmployeeVM);
        }

        public ViewResult EmployeeList()
        {
            var result = _employeeRepository.GetAllEmployees();
            return View(result);
        }

        public ViewResult LayoutTest()
        {
            var result = _employeeRepository.GetAllEmployees();
            ViewBag.PageTitle = "Usage of common Layout pages";

            return View(result);
        }

        public ViewResult RoutingTestEmployeeDetails(int? Id) //Conventional routing
        {
            Employe emp = new Employe();

            ViewBag.PageTitle = "Conventional Routing Configured";

            //Binding Model to View
            emp = _employeeRepository.GetEmployee(Id ?? 1);
            return View(emp);
        }


        [Route("")]
        [Route("Home")]
        [Route("Home/Index")]
        [Route("Home/AttributeRoutingEmployeeList")]
        public ViewResult AttributeRoutingEmployeeList()
        {
            var result = _employeeRepository.GetAllEmployees();
            return View("EmployeeList", result);
        }


        [Route("Home/AttributeRoutingEmployeeListWithParam/{Id?}")]
        public ViewResult AttributeRoutingEmployeeListWithParam(int? Id)
        {
            var result = _employeeRepository.GetEmployee(Id ?? 1);
            return View("RoutingTestEmployeeDetails", result);
        }
    }
}
