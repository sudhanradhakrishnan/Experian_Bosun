﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.DAL;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Asp.NetCoreDemo1
{
    public class Startup_Old1
    {
        private IConfiguration _config;

        public Startup_Old1(IConfiguration iconfig)
        {
            _config = iconfig;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            //9. To enable MVC services call the services.AddMvc() method

            //services.AddMvc(M => M.EnableEndpointRouting = false);
            services.AddMvcCore(M => M.EnableEndpointRouting = false).AddRazorViewEngine();

            // To enable converting data to XML in the controller the extention method AddXmlSerializerFormatters() is added. 
            //services.AddMvcCore(M => M.EnableEndpointRouting = false).AddXmlSerializerFormatters();

            //10. For Dependency Injection of IEmployeeRepository do one of the followig
            services.AddSingleton<IEmployeeRepository, MockEmployeeRepository>();
            //services.AddTransient<>
            //services.AddScoped<>
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILogger<Startup_Old1> logger)
        {

            //7. For Exception handling use UseDeveloperExceptionPage Middleware as below
            if (env.IsDevelopment())
            {
                //How many lines of Code to be displayed before and after exception Code.
                DeveloperExceptionPageOptions developerExceptionPageOptions = new DeveloperExceptionPageOptions();
                developerExceptionPageOptions.SourceCodeLineCount = 5;
                app.UseDeveloperExceptionPage(developerExceptionPageOptions);

                ///app.UseDeveloperExceptionPage();
            }
            //8. Handling exeption in all other environment other than Development
            //else if (env.IsProduction() || env.IsStaging() || env.IsEnvironment("UAT") || env.IsEnvironment("QA"))
            //{
            //    app.UseExceptionHandler("/Error");
            //}



            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapGet("/", async context =>
            //    {
            //        await context.Response.WriteAsync("Hello Ajo. ");
            //        //await context.Response.WriteAsync(System.Diagnostics.Process.GetCurrentProcess().ProcessName);
            //        //await context.Response.WriteAsync("/n" + _config["AjoKey1"]);
            //    });
            //});

            //................................................................................................
            ////4. Inorder to use default.html or default.htm or index.html or index.htm files Below Middleware is required
            ////This Middleware should be used before the UseStaticFiles() Middleware
            //app.UseDefaultFiles();

            //................................................................................................
            ////5. To display another default file with different name other than the above mentioned 4 names, eg:- 'foo.html'
            ////overload the Middleware app.UseDefaultFiles(); with DefaultFilesOptions parameter as below.

            //DefaultFilesOptions defaultFilesOptions = new DefaultFilesOptions();
            //defaultFilesOptions.DefaultFileNames.Clear();
            //defaultFilesOptions.DefaultFileNames.Add("foo.html");
            //app.UseDefaultFiles(defaultFilesOptions);

            //................................................................................................
            //3. Inorder to use Static files such as .Js file, .css file, image files, should give the below Middleware
            app.UseStaticFiles();

            //

            //app.UseRouting();
            app.UseMvcWithDefaultRoute();

            //................................................................................................
            ////6. Instead of using above 2 Middlewares ie, UseDefaultFiles(), UseStaticFiles() we can make use of a single MiddleWare ie,
            ////app.UseFileServer() which also include the UseDirectoryBrowser() Middleware

            //FileServerOptions fileServerOptions = new FileServerOptions();
            //fileServerOptions.DefaultFilesOptions.DefaultFileNames.Clear();
            //fileServerOptions.DefaultFilesOptions.DefaultFileNames.Add("foo.html");
            //app.UseFileServer(fileServerOptions);

            //................................................................................................
            ////2. Added new Middleware component
            //app.Use(async (context, next) =>
            //{
            //    await context.Response.WriteAsync("Middleware 1 incoming request. ");
            //    logger.LogInformation("Middleware 1 incoming request.");
            //    await next();
            //    await context.Response.WriteAsync("Middleware 1 outgoing response. ");
            //    logger.LogInformation("Middleware 1 outgoing response.");
            //});

            ////Added another Middleware component
            //app.Use(async (context, next) =>
            //{
            //    await context.Response.WriteAsync("Middleware 2 incoming request. ");
            //    logger.LogInformation("Middleware 2 incoming request.");
            //    await next();
            //    await context.Response.WriteAsync("Middleware 2 outgoing response. ");
            //    logger.LogInformation("Middleware 2 outgoing response.");
            //});
            //................................................................................................

            //1. The app.Run will be the last middleware method is the treminal method.
            //Aany Middleware can be added using app.Use() method and has to be added in the order of execution 
            //and the last one will be app.Run
            app.Run(async (context) =>
            {
                //7. For Exception handling, after adding the UseDeveloperExceptionPage Middleware, use the below code to throw exception
                //throw new Exception("Exception message : Some error occurred");
                //await context.Response.WriteAsync("The Hosting environment is : " + env.EnvironmentName);
                //logger.LogInformation("Middleware 3 incoming request.");

                await context.Response.WriteAsync("Hello Ajo ");
            });
        }
    }
}
