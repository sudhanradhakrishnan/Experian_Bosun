﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Model;

namespace Employee.DAL
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        private List<Employe> _EmployeeList;

        public MockEmployeeRepository()
        {
            _EmployeeList = new List<Employe>()
            {
                new Employe() { Id = 1, Name = "Mary", Email = "mary@yahoo.com", Department = "HR" },
                new Employe() { Id = 2, Name = "John", Email = "john@yahoo.com", Department = "IT" } ,
                new Employe() { Id = 3, Name = "Sam", Email = "sam@yahoo.com", Department = "IT"}
            };
        }

        public Employe GetEmployee(int Id)
        {
            return _EmployeeList.FirstOrDefault(e => e.Id == Id);
        }

        public IEnumerable<Employe> GetAllEmployees()
        {
            return _EmployeeList;
        }

        public Employe Add(Employe emp)
        {
            emp.Id = _EmployeeList.Max(emp => emp.Id) + 1;
            _EmployeeList.Add(emp);
            return emp;
        }

        public Employe Update(Employe empl)
        {
            Employe updEmp = _EmployeeList.FirstOrDefault(emp => emp.Id == empl.Id);
            updEmp.Name = empl.Name;
            updEmp.Email = empl.Email;
            updEmp.Department = empl.Department;
            return updEmp;
        }

        public Employe Delete(int empId)
        {
            Employe delEmp = _EmployeeList.FirstOrDefault(emp => emp.Id == empId);
            _EmployeeList.Remove(delEmp);
            return delEmp;
        }
    }
}
