﻿using Employee.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Employee.DAL
{
    public class SQLEmployeeRepository : IEmployeeRepository
    {
        private readonly EmpDbContext _empDbContext;
        public SQLEmployeeRepository(EmpDbContext dbContext)
        {
            _empDbContext = dbContext;
        }
        public Employe Add(Employe emp)
        {
            _empDbContext.EmployeeT.Add(emp);
            _empDbContext.SaveChanges();
            return emp;
        }

        public Employe Delete(int empId)
        {
            Employe emp = _empDbContext.EmployeeT.Find(empId);
            if (emp != null)
            {
                _empDbContext.EmployeeT.Remove(emp);
                _empDbContext.SaveChanges();
            }
            return emp;
        }

        public IEnumerable<Employe> GetAllEmployees()
        {
            return _empDbContext.EmployeeT;
        }

        public Employe GetEmployee(int Id)
        {
            return _empDbContext.EmployeeT.Find(Id);
        }

        public Employe Update(Employe empl)
        {
            //Employe updEmp = _empDbContext.EmployeeT.Find(empl.Id);

            //updEmp.Name = empl.Name;
            //updEmp.Email = empl.Email;
            //updEmp.Department = empl.Department;

            //_empDbContext.EmployeeT.Update(empl);

            var changedEmp = _empDbContext.EmployeeT.Attach(empl);
            changedEmp.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _empDbContext.SaveChanges();
            return empl;
        }
    }
}
